
#[cfg(test)]
mod team_example_regressions {
    use super::*;
    fn request(root: &Path) -> OnboardRequest {
        OnboardRequest {
            profile_name: "isolated-regression".into(), repository_path: root.into(),
            model: String::new(), model_digest: None, endpoint: None,
            verifier_executable: "python".into(), verifier_args: vec![],
            verification_files: vec!["pyproject.toml".into()],
            allowed_files: vec!["invoice.py".into()], workers: vec![],
            allow_test_edits: false, low_spec: false, by: "regression".into(),
        }
    }
    #[test]
    fn binary_acceptance_fixtures_must_remain_protected() {
        let root = tempfile::tempdir().unwrap();
        std::fs::create_dir(root.path().join("tests")).unwrap();
        std::fs::write(root.path().join("invoice.py"), "pass").unwrap();
        std::fs::write(root.path().join("pyproject.toml"), "[project]").unwrap();
        for name in ["snapshot.svg", "sample.png", "fixture.lock"] {
            std::fs::write(root.path().join("tests").join(name), [0, 255, 1]).unwrap();
        }
        crate::repository::git(root.path(), &["init", "-b", "main"]).unwrap();
        crate::repository::git(root.path(), &["add", "."]).unwrap();
        let mut req = request(root.path());
        protect_acceptance_files(&mut req).unwrap();
        println!("ACTUAL protected files: {:?}", req.verification_files);
        let missing: Vec<_> = ["tests/snapshot.svg", "tests/sample.png", "tests/fixture.lock"]
            .into_iter().filter(|p| !req.verification_files.iter().any(|v| v == p)).collect();
        assert!(missing.is_empty(), "UNPROTECTED acceptance inputs: {:?}", missing);
    }
    #[test]
    fn test_edit_mode_must_refuse_zero_protected_verifier_files() {
        let root = tempfile::tempdir().unwrap();
        let mut req = request(root.path());
        req.allow_test_edits = true;
        req.verification_files.clear();
        let result = protect_acceptance_files(&mut req);
        println!("ACTUAL allow_test_edits=true, protected=[]: {:?}", result);
        assert!(result.is_err(), "UNSAFE configuration accepted with no protected verifier files");
    }
}
